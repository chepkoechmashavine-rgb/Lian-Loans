# Lian Loans — starter website

A basic independent loan application form for applicants in the Democratic Republic of the Congo. Amounts are in CDF. It does **not** imitate Airtel or request account passwords, mobile-money PINs, bank credentials, or OTPs.

## Before deployment
1. Revoke the Telegram bot token that was pasted into the chat using **@BotFather** (`/revoke`) and generate a fresh token.
2. Keep the new token private. Do not put it in source code, HTML, GitHub, or messages.
3. Confirm that you are legally authorized to offer loans in the DRC. Add your registered business identity, physical/contact address, loan terms, interest/fees, privacy policy, complaint process, and any required regulatory disclosures before accepting real applications.
4. Review whether sending applicant phone numbers and names to Telegram is appropriate under applicable privacy laws. This starter sends those details only after the applicant checks the consent box.

## Deploy on Render
1. Create a GitHub repository and upload the contents of this folder.
2. In Render, choose **New + → Blueprint** and connect that repository (or create a Web Service with the settings below).
3. Set:
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:app`
4. In the Render service's **Environment** settings, add:
   - `TELEGRAM_BOT_TOKEN` = your newly generated bot token
   - `TELEGRAM_CHAT_ID` = your Telegram chat ID
5. Deploy. Render will provide a public `onrender.com` address.

## Telegram setup
- Open your bot in Telegram and send `/start` so it can message you.
- Confirm the chat ID is correct.
- Test with a dummy application before sharing the website.
- If notifications fail, check the Render logs. Never expose the bot token.

## Important limitations
This is a starter project, not a complete regulated lending platform. It does not calculate eligibility, approve loans, store applications in a database, authenticate administrators, or provide legally reviewed loan disclosures. The applicant's name, phone number, requested amount, and repayment period are sent to the configured Telegram chat. Protect that chat and restrict who can access it.
