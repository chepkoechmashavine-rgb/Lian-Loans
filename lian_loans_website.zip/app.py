import os
import re
from decimal import Decimal, InvalidOperation

import requests
from flask import Flask, render_template, request

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024  # small form only

def valid_phone(value):
    # Accept international-style numbers; applicant should include country code.
    cleaned = re.sub(r"[ \-()]", "", value or "")
    return bool(re.fullmatch(r"\+?[0-9]{8,15}", cleaned))

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/apply")
def apply():
    # Honeypot field: silently reject automated spam.
    if request.form.get("website", "").strip():
        return render_template("success.html")

    name = request.form.get("name", "").strip()
    phone = request.form.get("phone", "").strip()
    amount_raw = request.form.get("amount", "").strip()
    term = request.form.get("term", "").strip()
    consent = request.form.get("consent")

    errors = []
    if not 2 <= len(name) <= 80:
        errors.append("Enter your full name (2–80 characters).")
    if not valid_phone(phone):
        errors.append("Enter a valid phone number with country code.")
    try:
        amount = Decimal(amount_raw)
        if amount <= 0 or amount > Decimal("100000000"):
            errors.append("Enter a loan amount greater than 0 and within the allowed limit.")
    except (InvalidOperation, TypeError):
        amount = None
        errors.append("Enter a valid loan amount in CDF.")
    if term not in {"1 month", "3 months", "6 months", "9 months", "12 months"}:
        errors.append("Choose a repayment period.")
    if consent != "yes":
        errors.append("Consent is required before submitting.")

    if errors:
        return render_template("index.html", errors=errors, form=request.form), 400

    bot_token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID")
    if not bot_token or not chat_id:
        app.logger.error("Telegram configuration is missing.")
        return render_template("error.html"), 503

    # Send only the application details the applicant agreed to share.
    message = (
        "New Lian Loans application\n"
        f"Name: {name}\n"
        f"Phone: {phone}\n"
        f"Requested amount: {amount:,.2f} CDF\n"
        f"Repayment period: {term}\n"
        "Consent: Yes"
    )
    try:
        response = requests.post(
            f"https://api.telegram.org/bot{bot_token}/sendMessage",
            json={"chat_id": chat_id, "text": message},
            timeout=10,
        )
        response.raise_for_status()
        if not response.json().get("ok"):
            raise RuntimeError("Telegram did not accept the message")
    except Exception:
        app.logger.exception("Telegram notification failed")
        return render_template("error.html"), 503

    return render_template("success.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")))
